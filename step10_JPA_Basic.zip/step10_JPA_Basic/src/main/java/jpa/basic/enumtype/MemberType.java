package jpa.basic.enumtype;

public enum MemberType {
	NORMAL, VIP, VVIP, BLACK
}

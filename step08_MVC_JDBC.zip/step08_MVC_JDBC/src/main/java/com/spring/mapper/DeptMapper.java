package com.spring.mapper;

import com.spring.dto.Dept;

public interface DeptMapper {
	public Dept getDeptByDeptno(int deptno);
}

package com.spring.service;

import com.spring.dto.Dept;

public interface DeptService {
	public Dept getDeptByDeptno(int deptno);
}
